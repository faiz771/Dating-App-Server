@extends('layouts.app', ['cat_name' => 'accounts', 'page_name' => 'add_expense'])

@section('content')
    <div class="row layout-top-spacing" id="cancel-row">
        <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
            <div class="statbox widget box box-shadow">
                <div class="widget-header">
                    <div class="row">
                        <h4> Add Employee Expense </h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row layout-top-spacing" id="cancel-row">
        <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
            <div class="statbox widget box box-shadow">
                <div class="widget-header">
                    <form action="{{ route('employee_exp.update',$edit->id) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <label for="purchase">Employee</label>
                                <select class="form-control" name="employee">
                                     @if(!empty($user_roles))
                                         @foreach($user_roles as $user_role)
                                           @if(!empty($user_role))
                                            <option value="{{ $user_role->id }}" @if(!empty($edit->user_id)) {{ $edit->user_id == $user_role->id  ? 'selected' : ''}} @endif>{{ $user_role->user->name }}</option>
                                            @endif
                                         @endforeach
                                     @endif
                                </select>
                            </div>

                            <div class="form-group col-md-4">
                                <label for="purchase">Expense</label>
                                <input type="number" name="Expense" class="form-control" id="Expense"
                                    placeholder="Enter Expense" value="{{ $edit->expense }}">
                            </div>

                            <div class="form-group col-md-4">
                                <label for="expense">Category</label>
                                <input type="text" class="form-control" id="category" maxlength="13" name="Category"
                                    placeholder="Enter Category" value="{{ $edit->category }}">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary mt-3">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
