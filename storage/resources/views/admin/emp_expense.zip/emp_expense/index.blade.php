@extends('layouts.app', ['title' => 'Manage Employee Expense', 'cat_name' => 'accounts', 'page_name' => 'Manage_Employee_Expense'])

@section('content')
    <div class="row layout-top-spacing" id="cancel-row">
        <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
            <div class="statbox widget box box-shadow">
                <div class="widget-header">
                    <div class="row">
                        <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                            <h3>Manage Employee Expense</h3>
                            <a href="{{ route('employee_exp.create') }}" class="btn btn-success float-right" style="margin-top: -40px;"> Add Employee Expense </a>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>

    <div class="row layout-top-spacing" id="cancel-row">
        <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
            <div class="widget-content widget-content-area br-6">
                <table id="alter_pagination" class="table table-hover" style="width:100%">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Employee</th>
                            <th>Role</th>
                            <th>Expense</th>
                            <th>Category</th>
                            <th>Created</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                      
                        @if(!empty($expenses))
                        @foreach ($expenses as $expense)
                          @if(!empty($expense))
                            <tr>
                                <td> {{ $n++ }} </td>                             
                                <td> {{ isset($expense->user_role->user->name) ? $expense->user_role->user->name :''}}  </td>
                                <td> {{ isset($expense->user_role->role->name) ? $expense->user_role->role->name :''}}  </td>
                                <td> {{ $expense->expense }} </td>                             
                                <td> {{ $expense->category }} </td>                             
                                <td> {{date('m-d-Y h:i:s a ', strtotime($expense->created_at));}} </td>                             
                                <td align="center">
                                    <a href="{{ route('employee_exp.edit',$expense->id) }}" class="text-success" title="Edit"><i
                                        data-feather="edit"></i></a>
                                        
                                    <a href="javascript:void(0)" class="text-danger employee_ex_delete"
                                    data-id="{{ $expense->id }}" data-action="{{ url('/delete-empexpense/' . $expense->id) }}"
                                    title="Delete"><i data-feather="trash"></i></a>
                                </td>                             
                            </tr>
                            @endif
                        @endforeach
                    @endif

                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
