@extends('layouts.app', ['title' => 'Manage Faq', 'cat_name' => 'settings', 'page_name' => 'faq'])
@section('content')

    <div class="row layout-top-spacing" id="cancel-row">
        <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
            <div class="statbox widget box box-shadow">
                <div class="widget-header">
                    <div class="row">
                        <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                            <h3>Manage Faq</h3>
                            <a href="{{ route('faq.create') }}" class="btn btn-success float-right" style="margin-top: -40px;"> Add Faq </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row layout-top-spacing" id="cancel-row">
        <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
            <div class="widget-content widget-content-area br-6">
                <table id="alter_pagination" class="table table-hover" style="width:100%">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Question</th>
                            <th>Answer</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                      
                     @if(!empty($faqs))
                        @foreach ($faqs as $faq)
                          @if(!empty($faq))
                            <tr>
                                <td> {{ $n++ }} </td>                             
                               
                                <td> {{ $faq->question }} </td>                             
                                <td> {{ $faq->answer }} </td>                             
                                <td align="center">
                                    <a href="{{ route('faq.edit',$faq->id) }}" class="text-success" title="Edit"><i
                                        data-feather="edit"></i></a>
                                        
                                    <a href="javascript:void(0)" class="text-danger faq_delete"
                                    data-id="{{ $faq->id }}" data-action="{{ url('/delete-faqs/' . $faq->id) }}"
                                    title="Delete"><i data-feather="trash"></i></a>
                                </td>                             
                            </tr>
                            @endif
                        @endforeach
                    @endif

                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
